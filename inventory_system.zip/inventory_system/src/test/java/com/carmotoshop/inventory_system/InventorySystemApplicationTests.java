package com.carmotoshop.inventory_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventorySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
