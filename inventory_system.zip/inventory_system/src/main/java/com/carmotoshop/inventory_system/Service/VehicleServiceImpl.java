package com.carmotoshop.inventory_system.Service;

import com.carmotoshop.inventory_system.DAO.VehicleDAO;
import com.carmotoshop.inventory_system.Model.Vehicle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class VehicleServiceImpl implements VehicleService{

    @Autowired
    private VehicleDAO vehicleDAO;

    @Override
    @Transactional(readOnly = false)
    public Vehicle save(Vehicle vehicle) {
        return vehicleDAO.save(vehicle);
    }

    @Override
    @Transactional(readOnly = false)
    public void delete(Integer id) {
        vehicleDAO.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Vehicle findById(Integer id) {
        return vehicleDAO.findById(id).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Vehicle> findAll() {
        return (List<Vehicle>) vehicleDAO.findAll() ;
    }

}
