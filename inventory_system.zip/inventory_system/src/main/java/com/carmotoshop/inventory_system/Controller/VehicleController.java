package com.carmotoshop.inventory_system.Controller;

import com.carmotoshop.inventory_system.Model.Vehicle;
import com.carmotoshop.inventory_system.Service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.awt.print.Pageable;
import java.util.List;

@RestController
@CrossOrigin(origins = {"*"})
@RequestMapping("/api")
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @PostMapping("/addVehicle")
    public Vehicle save(@RequestBody Vehicle vehicle){
        return vehicleService.save(vehicle);
    }

    @GetMapping("/obtenerVehicles")
    ModelAndView Listar(List list){
        List<Vehicle> vehicles = vehicleService.findAll();
        return new ModelAndView("/Vehicles/Listar")
                .addObject("vehicles", vehicles);
    }
    //@GetMapping("/vehicles")
    //public List<Vehicle> vehicles(){
    //    return vehicleService.findAll();
    //}
    @GetMapping("/obtenerVehicle/{id}")
    public Vehicle mostrar(@PathVariable Integer id){
        return vehicleService.findById(id);
    }
    @PutMapping("/modificarVehicle/{id}")
    public Vehicle update(@RequestBody Vehicle vehicle,@PathVariable Integer id){

        Vehicle vehicleActual = vehicleService.findById(id);
        vehicleActual.setVehicleType(vehicle.getVehicleType());
        vehicleActual.setModelName(vehicle.getModelName());
        vehicleActual.setMake(vehicle.getMake());
        vehicleActual.setModelStartYear(vehicle.getModelStartYear());
        vehicleActual.setModelEndYear(vehicle.getModelEndYear());
        vehicleActual.setModelEngineDisplacement(vehicle.getModelEngineDisplacement());

        return vehicleService.save(vehicleActual);
    }
    @DeleteMapping("/eliminarVehicle/{id}")
    public void delete(@PathVariable Integer id){
        vehicleService.delete(id);
    }
}
