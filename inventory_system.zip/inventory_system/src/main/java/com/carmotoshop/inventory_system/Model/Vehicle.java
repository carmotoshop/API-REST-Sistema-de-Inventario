package com.carmotoshop.inventory_system.Model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "vehicle")
public class Vehicle implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vehicleid")
    private Integer id;

    @Column(name = "vehicletype")
    private String vehicleType;

    @Column(name = "modelname")
    private String modelName;

    @Column(name = "make")
    private String 	make;

    @Column(name = "modelstartyear")
    private String modelStartYear;

    @Column(name = "modelendyear")
    private String modelEndYear;

    @Column(name = "modelenginedisplacement")
    private String modelEngineDisplacement;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModelStartYear() {
        return modelStartYear;
    }

    public void setModelStartYear(String modelStartYear) {
        this.modelStartYear = modelStartYear;
    }

    public String getModelEndYear() {
        return modelEndYear;
    }

    public void setModelEndYear(String modelEndYear) {
        this.modelEndYear = modelEndYear;
    }

    public String getModelEngineDisplacement() {
        return modelEngineDisplacement;
    }

    public void setModelEngineDisplacement(String modelEngineDisplacement) {
        this.modelEngineDisplacement = modelEngineDisplacement;
    }

    private static final long serialVersionUID = 1L;
}
