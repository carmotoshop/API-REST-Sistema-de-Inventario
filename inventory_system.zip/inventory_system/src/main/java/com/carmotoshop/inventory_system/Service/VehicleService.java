package com.carmotoshop.inventory_system.Service;

import com.carmotoshop.inventory_system.Model.Vehicle;

import java.util.*;

public interface VehicleService {

    public Vehicle save(Vehicle vehicle);

    public void delete(Integer id);

    public Vehicle findById(Integer id);

    public List<Vehicle> findAll();


}
