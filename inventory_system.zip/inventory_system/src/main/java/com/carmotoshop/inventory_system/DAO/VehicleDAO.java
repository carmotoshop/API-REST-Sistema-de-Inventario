package com.carmotoshop.inventory_system.DAO;

import com.carmotoshop.inventory_system.Model.Vehicle;
import org.springframework.data.repository.CrudRepository;

public interface VehicleDAO extends CrudRepository<Vehicle,Integer> {

}
